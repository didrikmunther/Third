//
//  CTile.cpp
//  Third
//
//  Created by Didrik Munther on 02/04/15.
//  Copyright (c) 2015 Didrik Munther. All rights reserved.
//

#include "CTile.h"

CTile::CTile(sf::IntRect rect, int type) :
    _rect(rect), _type(type) {
        
}
