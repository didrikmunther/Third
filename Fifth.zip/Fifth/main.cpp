//
//  main.cpp
//  Third
//
//  Created by Didrik Munther on 12/03/15.
//  Copyright (c) 2015 Didrik Munther. All rights reserved.
//

#include "CGame.h"
#include "CServer.h"

#include <iostream>


int main(int argc, const char * argv[]){
    
    //CServer server;
    
    //return server.onExecute();
    
    CGame game;
    
    return game.onExecute();
    
}