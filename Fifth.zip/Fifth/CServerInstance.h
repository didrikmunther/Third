//
//  CServerInstance.h
//  Fifth
//
//  Created by Didrik Munther on 28/05/15.
//  Copyright (c) 2015 Didrik Munther. All rights reserved.
//

#ifndef __Fifth__CServerInstance__
#define __Fifth__CServerInstance__

#include <stdio.h>

#endif /* defined(__Fifth__CServerInstance__) */
