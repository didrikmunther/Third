//
//  NFile.cpp
//  Third
//
//  Created by Didrik Munther on 13/03/15.
//  Copyright (c) 2015 Didrik Munther. All rights reserved.
//

#include "NFile.h"
#include "Define.h"

CSpriteSheet* NFile::loadSpriteSheet() {
    
    return nullptr;
}